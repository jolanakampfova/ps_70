#define TRIG_PIN     D9
#define ECHO_PIN     D10

// motor 
#define MOTOR_A1    D5
#define MOTOR_A2    D6

// pump
#define MOTOR_B1    D7
#define MOTOR_B2    D8

#define TRIGGER_DIST 20

void setup() {
  Serial.begin(9600);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(MOTOR_A1, OUTPUT);
  pinMode(MOTOR_A2, OUTPUT);

  pinMode(MOTOR_B1, OUTPUT);
  pinMode(MOTOR_B2, OUTPUT);

  Serial.println("System ready. Starting test...");
  runStartupTest();
}

void loop() {
  long distance = readDistance();
  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  if (distance > 0 && distance < TRIGGER_DIST) {
    Serial.println("Object detected — motor and pump ON");
    setMotor(true, 180);   // forward, ~70% speed
    setPump(true, 200);    // on, ~78% speed
  } else {
    Serial.println("Clear — motor and pump OFF");
    setMotor(false, 0);
    setPump(false, 0);
  }

  delay(500);
}

// Returns distance in cm, or -1 on timeout
long readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000); // 30ms timeout
  if (duration == 0) return -1;
  return duration * 0.034 / 2;
}

void setMotor(bool forward, int speed) {
  digitalWrite(MOTOR_A1, forward ? HIGH : LOW);
  digitalWrite(MOTOR_A2, forward ? LOW : HIGH);
}

void setPump(bool on, int speed) {
  digitalWrite(MOTOR_B1, on ? HIGH : LOW);
  digitalWrite(MOTOR_B2, on ? LOW : HIGH);
}

// Briefly spins each component on startup to confirm wiring
void runStartupTest() {
  Serial.println("Testing motor...");
  setMotor(true, 150);
  delay(1000);
  setMotor(false, 0);
  delay(500);

  Serial.println("Testing pump...");
  setPump(true, 150);
  delay(1000);
  setPump(false, 0);
  delay(500);

  Serial.println("Startup test done.");
}
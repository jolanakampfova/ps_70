#define PUMP_DIR  2
#define PUMP_EN   3
#define RIM_DIR   4   // D0/D1 are Serial TX/RX on Uno — use D4/D5 instead
#define RIM_EN    5

#define PUMP_SPEED    200
#define RIM_SPEED     180
#define PUMP_PULSE_MS 400
#define DRAIN_MS      15000

const int   CAL_COUNT                = 10;
const char* CAL_NOTES[CAL_COUNT]     = { "B4", "C5", "D5", "E5", "F5", "G5", "A5", "B5", "C6", "D6" };
const int   CAL_LEVELS[CAL_COUNT]    = {  28,   24,   20,   17,   14,   11,    8,    6,    4,    2  };

int  waterLevel = 0;
bool rimOn      = false;

void pumpStop() {
  analogWrite(PUMP_EN, 0);
}

// Draining has no positional feedback, so we always run for a fixed duration
// from a known-empty state. Startup drain establishes that baseline.
void drain() {
  analogWrite(RIM_EN, 0);
  rimOn = false;
  digitalWrite(PUMP_DIR, LOW);
  analogWrite(PUMP_EN, PUMP_SPEED);
  delay(DRAIN_MS);
  pumpStop();
  waterLevel = 0;
}

void fillToLevel(int target) {
  if (target <= waterLevel) return;
  digitalWrite(PUMP_DIR, HIGH);
  while (waterLevel < target) {
    analogWrite(PUMP_EN, PUMP_SPEED);
    delay(PUMP_PULSE_MS);
    pumpStop();
    delay(80);
    waterLevel++;
  }
}

void setLevel(int target) {
  if (target < waterLevel) {
    drain();
  }
  fillToLevel(target);
}

int levelForNote(const String& note) {
  for (int i = 0; i < CAL_COUNT; i++) {
    if (note.equalsIgnoreCase(CAL_NOTES[i])) return CAL_LEVELS[i];
  }
  return -1;
}

void rimStart() {
  digitalWrite(RIM_DIR, HIGH);
  analogWrite(RIM_EN, RIM_SPEED);
  rimOn = true;
}

void rimStop() {
  analogWrite(RIM_EN, 0);
  rimOn = false;
}

void play(const String& note) {
  int target = levelForNote(note);
  if (target < 0) {
    Serial.println("ERR:unknown_note");
    return;
  }
  rimStop();
  Serial.println("STATUS:adjusting");
  setLevel(target);
  rimStart();
  Serial.print("STATUS:playing ");
  Serial.println(note);
}

void setup() {
  pinMode(PUMP_DIR, OUTPUT);
  pinMode(PUMP_EN,  OUTPUT);
  pinMode(RIM_DIR,  OUTPUT);
  pinMode(RIM_EN,   OUTPUT);

  digitalWrite(PUMP_DIR, LOW);
  digitalWrite(RIM_DIR,  HIGH);
  pumpStop();
  rimStop();

  Serial.begin(9600);
  Serial.println("STATUS:draining");
  drain();
  Serial.println("STATUS:ready");
}

void loop() {
  if (!Serial.available()) return;

  String cmd = Serial.readStringUntil('\n');
  cmd.trim();

  if (cmd == "STOP") {
    rimStop();
    Serial.println("STATUS:stopped");
  } else if (cmd == "DRAIN") {
    Serial.println("STATUS:draining");
    drain();
    Serial.println("STATUS:ready");
  } else if (cmd == "LIST") {
    Serial.print("NOTES:");
    for (int i = 0; i < CAL_COUNT; i++) {
      Serial.print(CAL_NOTES[i]);
      if (i < CAL_COUNT - 1) Serial.print(",");
    }
    Serial.println();
  } else if (cmd.startsWith("PLAY:")) {
    play(cmd.substring(5));
  }
}

// === SINGING GLASS — CALIBRATION SKETCH ===
//
// WIRING (assumes L298N or similar H-bridge for each motor):
//   D2 → PUMP direction pin   (HIGH = fill, LOW = drain)
//   D3 → PUMP enable/PWM pin  (D3 supports hardware PWM on Uno)
//   D4 → RIM motor direction  (was D0 — D0/D1 are Serial TX/RX, can't use them)
//   D5 → RIM motor enable     (D5 supports hardware PWM on Uno)
//
// HOW TO CALIBRATE:
//   1. Make sure the glass is empty and the rim motor is NOT touching the glass.
//   2. Open Serial Monitor at 9600 baud (with "Newline" line ending).
//   3. Type 'S' → press Send to start the rim motor spinning on the glass.
//   4. Type '+' to add water one step at a time. Listen for the pitch.
//   5. When you hear a clear, stable note, type 'C', press Send, then type the note
//      name (e.g. G4) and press Send again.
//   6. Keep adding water and saving notes until you've mapped all the pitches you want.
//   7. Type 'P' to print the calibration table — copy it into main.ino.
//
// COMMANDS (send via Serial Monitor):
//   +   add one step of water
//   -   remove one step of water
//   F   fast fill (5 steps at once)
//   D   drain completely (runs drain pump for 15 s)
//   S   toggle rim motor on/off
//   C   save a calibration point for the current water level
//   P   print the full calibration table (copy into main.ino)
//   ?   show help

#define PUMP_DIR   0
#define PUMP_EN    1
#define RIM_DIR    3
#define RIM_EN     2

#define PUMP_SPEED     200   // 0–255 PWM
#define RIM_SPEED      180   // 0–255 PWM
#define PUMP_PULSE_MS  400   // one "step" of water in milliseconds
#define DRAIN_TIME_MS  15000 // drain run duration for a full glass

// Water level is tracked as a pulse count from empty (0 = empty).
// It is only meaningful within a single power-on session.
int waterLevel = 0;
bool rimRunning = false;

struct CalPoint {
  char note[8];
  int  level;
};
CalPoint calData[40];
int calCount = 0;

// ── motor helpers ──────────────────────────────────────────────

void pumpFill(int steps = 1) {
  digitalWrite(PUMP_DIR, HIGH);
  for (int i = 0; i < steps; i++) {
    analogWrite(PUMP_EN, PUMP_SPEED);
    delay(PUMP_PULSE_MS);
    analogWrite(PUMP_EN, 0);
    delay(80);
    waterLevel++;
  }
  Serial.print("Water level: "); Serial.println(waterLevel);
}

void pumpDrain(int steps = 1) {
  digitalWrite(PUMP_DIR, LOW);
  for (int i = 0; i < steps; i++) {
    analogWrite(PUMP_EN, PUMP_SPEED);
    delay(PUMP_PULSE_MS);
    analogWrite(PUMP_EN, 0);
    delay(80);
    if (waterLevel > 0) waterLevel--;
  }
  Serial.print("Water level: "); Serial.println(waterLevel);
}

void drainAll() {
  Serial.println("Draining completely (15 s)...");
  analogWrite(RIM_EN, 0);  // stop rim so we don't damage motor dry
  rimRunning = false;
  digitalWrite(PUMP_DIR, LOW);
  analogWrite(PUMP_EN, PUMP_SPEED);
  delay(DRAIN_TIME_MS);
  analogWrite(PUMP_EN, 0);
  waterLevel = 0;
  Serial.println("Done. Level reset to 0.");
}

void toggleRim() {
  rimRunning = !rimRunning;
  if (rimRunning) {
    digitalWrite(RIM_DIR, HIGH);
    analogWrite(RIM_EN, RIM_SPEED);
    Serial.println("Rim motor ON");
  } else {
    analogWrite(RIM_EN, 0);
    Serial.println("Rim motor OFF");
  }
}

// ── calibration helpers ────────────────────────────────────────

void saveCalPoint() {
  Serial.print("Current level is ");
  Serial.print(waterLevel);
  Serial.println(". Enter note name (e.g. C4, G#4, Bb5) then press Send:");

  // wait for the note name to arrive
  unsigned long t = millis();
  while (!Serial.available() && millis() - t < 30000) delay(10);
  if (!Serial.available()) { Serial.println("Timed out."); return; }

  String note = Serial.readStringUntil('\n');
  note.trim();
  if (note.length() == 0) { Serial.println("Cancelled."); return; }
  if (calCount >= 40)     { Serial.println("Table full (40 max)."); return; }

  note.toCharArray(calData[calCount].note, 8);
  calData[calCount].level = waterLevel;
  calCount++;

  Serial.print("Saved: "); Serial.print(note);
  Serial.print(" → level "); Serial.println(waterLevel);
}

void printCalibration() {
  if (calCount == 0) { Serial.println("No calibration points yet."); return; }

  Serial.println(F("\n======= COPY INTO main.ino ======="));
  Serial.print(F("const int CAL_COUNT = ")); Serial.print(calCount); Serial.println(F(";"));

  Serial.print(F("const char* CAL_NOTES[CAL_COUNT] = {"));
  for (int i = 0; i < calCount; i++) {
    Serial.print(F("\""));
    Serial.print(calData[i].note);
    Serial.print(F("\""));
    if (i < calCount - 1) Serial.print(F(", "));
  }
  Serial.println(F("};"));

  Serial.print(F("const int CAL_LEVELS[CAL_COUNT] = {"));
  for (int i = 0; i < calCount; i++) {
    Serial.print(calData[i].level);
    if (i < calCount - 1) Serial.print(F(", "));
  }
  Serial.println(F("};"));
  Serial.println(F("======= END =======\n"));
}

void printHelp() {
  Serial.println(F("\n=== SINGING GLASS CALIBRATION ==="));
  Serial.println(F("  +  add one water step"));
  Serial.println(F("  -  remove one water step"));
  Serial.println(F("  F  fast fill (5 steps)"));
  Serial.println(F("  D  drain completely"));
  Serial.println(F("  S  toggle rim motor"));
  Serial.println(F("  C  save calibration point"));
  Serial.println(F("  P  print calibration table"));
  Serial.println(F("  ?  this help"));
  Serial.print(F("Current level: ")); Serial.println(waterLevel);
}

// ── setup / loop ───────────────────────────────────────────────

void setup() {
  pinMode(PUMP_DIR, OUTPUT); pinMode(PUMP_EN, OUTPUT);
  pinMode(RIM_DIR,  OUTPUT); pinMode(RIM_EN,  OUTPUT);

  digitalWrite(PUMP_DIR, LOW); analogWrite(PUMP_EN, 0);
  digitalWrite(RIM_DIR, HIGH); analogWrite(RIM_EN, 0);

  Serial.begin(9600);
  printHelp();
}

void loop() {
  if (!Serial.available()) return;

  char cmd = Serial.read();
  // consume the rest of the line
  while (Serial.available() && Serial.peek() != '\n') Serial.read();

  switch (cmd) {
    case '+':           pumpFill(1);  break;
    case '-':           pumpDrain(1); break;
    case 'F': case 'f': pumpFill(5);  break;
    case 'D': case 'd': drainAll();   break;
    case 'S': case 's': toggleRim();  break;
    case 'C': case 'c': saveCalPoint(); break;
    case 'P': case 'p': printCalibration(); break;
    case '?':           printHelp();  break;
    default: break;
  }
}
